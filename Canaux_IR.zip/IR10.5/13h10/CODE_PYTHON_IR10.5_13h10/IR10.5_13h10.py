import xml.etree.ElementTree as ET #pour lire les fichiers .XML
import xarray as xr #pour lire les fichiers .NC
import os
import numpy as np
import matplotlib.pyplot as plt
from pyproj import Proj, transform  

#%% #récupèrer les fichiers

#où se trouvent tous les fichiers sur mon pc (juste pour 13h10)
dossier = r"C:\Users\Louis\OneDrive\Documents\IPSA\PMI_13h10\IR10.5_13h10"

#analyse du fichier Manifest.xml
tree = ET.parse(os.path.join(dossier, "manifest.xml"))
root = tree.getroot()
ns = {'eum': 'http://www.eumetsat.int/sip'}

#on récupère tous les fichiers .nc
paths = [elem.text for elem in root.findall('.//eum:path', ns) if elem.text.endswith('.nc')]
#vérification du nombre de fichiers .nc récupérés
print("Nombre de fichiers trouvés :", len(paths))

#%% #test sur le premier fichier .nc

# #on lit les variables
# fichier_test = os.path.join(dossier, paths[0])
# ds = xr.open_dataset(fichier_test)


# #on récupère IR10.5
# ds_ir105 = xr.open_dataset(fichier_test, group="data/ir_105_hr/measured")

# #récupération des variables utiles
# eff = ds_ir105["effective_radiance"]
# k_rad = ds_ir105["radiance_unit_conversion_coefficient"]
# wn  = ds_ir105["radiance_to_bt_conversion_coefficient_wavenumber"]
# c1  = ds_ir105["radiance_to_bt_conversion_constant_c1"]
# c2  = ds_ir105["radiance_to_bt_conversion_constant_c2"]
# a   = ds_ir105["radiance_to_bt_conversion_coefficient_a"]
# b   = ds_ir105["radiance_to_bt_conversion_coefficient_b"]

# #passage de la radiance effective à la radiance "physique"
# L = eff * k_rad

# #calcul de la température de brillance IR10.5 en K
# BT_planck = c2 * wn / np.log(1 + (c1 * wn**3) / L)
# BT_105 = a * BT_planck + b
# BT_105.name = "BT_105"


#%% #pour tous les fichiers .nc

bt_105_list = []
for p in paths:
    fichier = os.path.join(dossier, p)
    #on ouvre le groupe IR10.5 mesuré
    ds_ir105_all = xr.open_dataset(fichier, group="data/ir_105_hr/measured")
    #si pas de radiance mesurée, on skip
    if "effective_radiance" not in ds_ir105_all:
        ds_ir105_all.close()
        continue

    #récup des variables utiles
    eff_all = ds_ir105_all["effective_radiance"]
    k_rad_all = ds_ir105_all["radiance_unit_conversion_coefficient"]
    wn_all  = ds_ir105_all["radiance_to_bt_conversion_coefficient_wavenumber"]
    c1_all  = ds_ir105_all["radiance_to_bt_conversion_constant_c1"]
    c2_all  = ds_ir105_all["radiance_to_bt_conversion_constant_c2"]
    a_all   = ds_ir105_all["radiance_to_bt_conversion_coefficient_a"]
    b_all   = ds_ir105_all["radiance_to_bt_conversion_coefficient_b"]

    #passage radiance effective vers radiance "physique"
    L_all = eff_all * k_rad_all
    
    #BT planck + correction linéaire
    BT_planck_all = c2_all * wn_all / np.log(1 + (c1_all * wn_all**3) / L_all)
    BT_105_all = a_all * BT_planck_all + b_all
    BT_105_all.name = "BT_105"
    bt_105_list.append(BT_105_all)
    ds_ir105_all.close()

print("Nombre total de fichiers .nc traités pour IR10.5 :", len(bt_105_list))


#%% #combiner tous les fichiers .nc

#on convertit chaque DataArray en Dataset pour que combine_by_coords marche
bt_105_ds_list = [da.to_dataset() for da in bt_105_list]

#on combine par coordonnées (x, y)
bt_105_full_ds = xr.combine_by_coords(bt_105_ds_list)


#on récupère la DataArray
bt_105_full = bt_105_full_ds["BT_105"]

# On ne trie pas ici pour éviter les problèmes de coordonnées
print(f"Dimensions image IR10.5 : {bt_105_full.shape}")

#%% #affichage du monde entier

# plt.figure(figsize=(10,8))
# # On affiche sans trier, mais on inverse l'axe x pour corriger l'effet miroir
# bt_105_full.plot.imshow()
# plt.gca().invert_xaxis() #
# plt.xlabel("")  
# plt.ylabel("")
# plt.title("BT 10.5 µm (K)")
# plt.show()


#%% #sauvegarde des données du monde entier

# bt_105_full.to_netcdf("bt_105_13h10.nc")

#%% CALCUL DES COORDONNÉES GÉOGRAPHIQUES
# Les coordonnées x,y sont en radians dans la projection géostationnaire
# Il faut les convertir en latitude/longitude

# Récupérer les coordonnées x et y (en radians)
x_coords = bt_105_full.x.values  # Array 1D des coordonnées x
y_coords = bt_105_full.y.values  # Array 1D des coordonnées y

# Créer une grille 2D à partir des coordonnées 1D
Y, X = np.meshgrid(y_coords, x_coords, indexing='ij')

# PARAMÈTRES DU SATELLITE MTG
satellite_height = 35786023.0  # Altitude du satellite en mètres (35786 km)
satellite_longitude = 0.0  # Le satellite est positionné à 0°E

# CONVERSION : Radians vers Mètres
X_m = X * satellite_height
Y_m = Y * satellite_height

# DÉFINIR LES PROJECTIONS
proj_geos = Proj(f'+proj=geos +lon_0={satellite_longitude} +h={satellite_height} +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs +sweep=y')
proj_latlon = Proj('+proj=latlong +ellps=WGS84')

# CONVERSION : Projection géostationnaire Lat/Lon
lon, lat = transform(proj_geos, proj_latlon, X_m.flatten(), Y_m.flatten())

# RESHAPE : Revenir à une grille 2D
lon = lon.reshape(X.shape)
lat = lat.reshape(X.shape)

#%% ZOOM SUR TOULOUSE
# Maintenant qu'on a les coordonnées géographiques, on peut localiser Toulouse

lat_tlse = 43.6045  # Latitude de Toulouse
lon_tlse = -1.4440  # Longitude de Toulouse

# TROUVER LE PIXEL LE PLUS PROCHE DE TOULOUSE
dist = np.sqrt((lat - lat_tlse)**2 + (lon - lon_tlse)**2)

# Trouver l'indice du pixel avec la distance minimale
iy, ix = np.unravel_index(np.argmin(dist), dist.shape)

# DÉFINIR UNE FENÊTRE DE ZOOM AUTOUR DE TOULOUSE
radius = 25 # Nombre de pixels de part et d'autre de Toulouse

# Calculer les limites du zoom en s'assurant de rester dans l'image
x_min = max(ix - radius, 0)
x_max = min(ix + radius, bt_105_full.sizes["x"])
y_min = max(iy - radius, 0)
y_max = min(iy + radius, bt_105_full.sizes["y"])

# EXTRAIRE LES DONNÉES DU ZOOM
# Pour les données xarray, on garde l'ordre original
bt_zoom = bt_105_full.isel(x=slice(x_min, x_max), y=slice(y_min, y_max))


# Sauvegarder les données du zoom sur Toulouse
bt_zoom.to_netcdf("bt_105_zoom_toulouse_13h10_radius_25.nc")

# Pour les coordonnées, on extrait les mêmes indices
# IMPORTANT: Ces indices correspondent aux tableaux lat/lon qui ont la même forme
lat_zoom = lat[y_min:y_max, x_min:x_max]
lon_zoom = lon[y_min:y_max, x_min:x_max]

#%% AFFICHAGE DU ZOOM 

plt.figure(figsize=(10, 10))

# On utilise pcolormesh avec les coordonnées et données dans le même ordre
# On n'applique pas de sortby pour éviter les incohérences

plt.pcolormesh(lon_zoom, lat_zoom, bt_zoom.values, shading='auto', cmap='RdYlBu_r')



# Ajouter un point rouge pour visualiser Toulouse
plt.scatter(lon_tlse, lat_tlse, color="red", s=100, marker='.', 
            edgecolors='white', linewidths=2, label="Toulouse", zorder=10)

# CORRECTION: Pour corriger l'effet miroir, on inverse l'axe x
plt.gca().invert_xaxis()


plt.xlabel("Longitude (°)")
plt.ylabel("Latitude (°)")
plt.title("IR10.5_13h10_radius_25")
plt.grid(True, alpha=0.3, linestyle='--')
plt.tight_layout()
plt.savefig('IR10.5_13h10_radius_25.png')
plt.show()